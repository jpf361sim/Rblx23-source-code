{
    "IsLoginCodeButtonDisplayed": true,
    "IsCodeValidationDisplayed": true,
    "ShouldEnableCrossDeviceLoginInitiatorExperiments": true,
    "ShouldEnableCrossDeviceLoginConfirmerExperiments": true,
    "ShouldFrontLoadQrCode": true
}