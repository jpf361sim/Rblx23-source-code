{
    "isPending": false,
    "sessionStatus": 1,
    "sessionErrorCode": 0,
    "isVerified": true,
    "verifiedAge": 18,
    "isSeventeenPlus": true
}
