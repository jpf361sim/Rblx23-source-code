<?php
require_once 'site.php';
require_once 'content/functions.php';
if(!$logged){
die('<META http-equiv=refresh content=0;URL=/>');
exit;
}
$get->header('ROBLOX is powered by a growing community of over 300,000 creators who produce an infinite variety of highly immersive experiences. These experiences range from 3D multiplayer games and competitions, to interactive adventures where friends can take on new personas imagining what it would be like to be a dinosaur, a miner in a quarry or an astronaut on a space exploration.', 'Badges', 'https://images.rbxcdn.com/fb70fd2b56107a0d43f2f98658885702.jpg');
?>
<!DOCTYPE html>
<html xmlns:fb="https://www.facebook.com/2008/fbml">
<!-- MachineID: WEB139 -->
<head id="ctl00_Head1">
<title>
  Badges - ROBLOX
</title>
        <meta http-equiv="X-UA-Compatible" content="IE=edge,requiresActiveX=true"/>
    
<link rel="stylesheet" href="https://web.archive.org/web/20160429035611cs_/https://static.rbxcdn.com/css/MainCSS___7348ffc0fe5d87eeb6c5a97d7527e381_m.css/fetch"/>

<link rel="stylesheet" href="https://web.archive.org/web/20160429035611cs_/https://static.rbxcdn.com/css/page___f2c2615d8772503ad707f18f6a663d28_m.css/fetch"/>

        <link href="/favicon.ico" rel="icon"/>
    <link rel="icon" type="image/vnd.microsoft.icon" href="/favicon.ico"/><meta http-equiv="Content-Type" content="text/html; charset=utf-8"/><meta http-equiv="Content-Language" content="en-us"/><meta name="author" content="ROBLOX Corporation"/><meta id="ctl00_metadescription" name="description" content="ROBLOX is powered by a growing community of over 300,000 creators who produce an infinite variety of highly immersive experiences. These experiences range from 3D multiplayer games and competitions, to interactive adventures where friends can take on new personas imagining what it would be like to be a dinosaur, a miner in a quarry or an astronaut on a space exploration."/><meta id="ctl00_metakeywords" name="keywords" content="free games, online games, building games, virtual worlds, free mmo, gaming cloud, physics engine"/>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-1.11.1.min.js"></script>
<script type="text/javascript">window.jQuery || document.write("<script type='text/javascript' src='/js/jquery/jquery-1.11.1.js'><\/script>")</script>
<script type="text/javascript" src="https://ajax.aspnetcdn.com/ajax/jquery.migrate/jquery-migrate-1.2.1.min.js"></script>
<script type="text/javascript">window.jQuery || document.write("<script type='text/javascript' src='/js/jquery/jquery-migrate-1.2.1.js'><\/script>")</script>

    <script type="text/javascript">

        var _gaq = _gaq || [];

            window.GoogleAnalyticsDisableRoblox2 = true;
        _gaq.push(['b._setAccount', 'UA-486632-1']);
        _gaq.push(['b._setCampSourceKey', 'rbx_source']);
        _gaq.push(['b._setCampMediumKey', 'rbx_medium']);
        _gaq.push(['b._setCampContentKey', 'rbx_campaign']);

            _gaq.push(['b._setDomainName', 'rb16.ct8.pl']);

            _gaq.push(['b._setCustomVar', 1, 'Visitor', 'Anonymous', 2]);
    _gaq.push(['b._trackPageview']);


        _gaq.push(['c._setAccount', 'UA-26810151-2']);
            _gaq.push(['c._setDomainName', 'rb16.ct8.pl']);
        
        (function () {
            var ga = document.createElement('script');
            ga.type = 'text/javascript';
            ga.async = true;
            ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'https://www') + '.google-analytics.com/ga.js';
            var s = document.getElementsByTagName('script')[0];
            s.parentNode.insertBefore(ga, s);
        })();
    </script>
<script type="text/javascript" src="https://js.rbxcdn.com/01a58c60229b3d30de7b4f9170921d7e.js"></script>
        <script type="text/javascript">
            if (Roblox && Roblox.EventStream) {
                Roblox.EventStream.Init("https://ecsv2.sitetest3.bladeitter.cf/www/e.png",
                    "https://ecsv2.sitetest3.bladeitter.cf/www/e.png",
                    "https://ecsv2.sitetest3.bladeitter.cf/pe?t=studio",
                    "https://ecsv2.sitetest3.bladeitter.cf/pe?t=diagnostic");
            }
        </script>


<script type="text/javascript">
    if (Roblox && Roblox.PageHeartbeatEvent) {
        Roblox.PageHeartbeatEvent.Init([2,8,20,60]);
    }
</script><script type="text/javascript">Roblox.config.externalResources = [];Roblox.config.paths['Pages.Catalog'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/c14a216bd7773e7b637b4e6c3c2e619d.js';Roblox.config.paths['Pages.CatalogShared'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/962d5b2c17eda7dc135bb442c25afff9.js';Roblox.config.paths['Widgets.AvatarImage'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/6bac93e9bb6716f32f09db749cec330b.js';Roblox.config.paths['Widgets.DropdownMenu'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/7b436bae917789c0b84f40fdebd25d97.js';Roblox.config.paths['Widgets.GroupImage'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/33d82b98045d49ec5a1f635d14cc7010.js';Roblox.config.paths['Widgets.HierarchicalDropdown'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/3368571372da9b2e1713bb54ca42a65a.js';Roblox.config.paths['Widgets.ItemImage'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/8babd891cf420dfe3999b3824a0154cb.js';Roblox.config.paths['Widgets.PlaceImage'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/f2697119678d0851cfaa6c2270a727ed.js';Roblox.config.paths['Widgets.SurveyModal'] = 'https://web.archive.org/web/20160429035611/https://js.rbxcdn.com/d6e979598c460090eafb6d38231159f6.js';</script><script type="text/javascript">
    $(function () {
        Roblox.JSErrorTracker.initialize({ 'suppressConsoleError': true});
    });
</script><script type="text/javascript" src="https://web.archive.org/web/20160429035611js_/https://js.rbxcdn.com/16994b0cbe9c1d943e0de0fade860343.js"></script>


            <link rel="canonical" href="https://rb16.ct8.pl/Badges.aspx"/>
        <script type="text/javascript">
if (typeof(Roblox) === "undefined") { Roblox = {}; }
Roblox.Endpoints = Roblox.Endpoints || {};
Roblox.Endpoints.Urls = Roblox.Endpoints.Urls || {};
Roblox.Endpoints.Urls['/api/item.ashx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/api/item.ashx';
Roblox.Endpoints.Urls['/asset/'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset/';
Roblox.Endpoints.Urls['/client-status/set'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/client-status/set';
Roblox.Endpoints.Urls['/client-status'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/client-status';
Roblox.Endpoints.Urls['/game/'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/';
Roblox.Endpoints.Urls['/game/edit.ashx'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/edit.ashx';
Roblox.Endpoints.Urls['/game/getauthticket'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/getauthticket';
Roblox.Endpoints.Urls['/game/placelauncher.ashx'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/placelauncher.ashx';
Roblox.Endpoints.Urls['/game/preloader'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/preloader';
Roblox.Endpoints.Urls['/game/report-stats'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/report-stats';
Roblox.Endpoints.Urls['/game/report-event'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/report-event';
Roblox.Endpoints.Urls['/game/updateprerollcount'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/game/updateprerollcount';
Roblox.Endpoints.Urls['/login/default.aspx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/login/default.aspx';
Roblox.Endpoints.Urls['/my/character.aspx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/my/character.aspx';
Roblox.Endpoints.Urls['/my/money.aspx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/my/money.aspx';
Roblox.Endpoints.Urls['/chat/chat'] = 'https://web.archive.org/web/20160429035611/https://misc.sitetest3.bladeitter.cf/chat/chat';
Roblox.Endpoints.Urls['/presence/users'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/presence/users';
Roblox.Endpoints.Urls['/presence/user'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/presence/user';
Roblox.Endpoints.Urls['/friends/list'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/friends/list';
Roblox.Endpoints.Urls['/navigation/getCount'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/navigation/getCount';
Roblox.Endpoints.Urls['/catalog/browse.aspx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/catalog/browse.aspx';
Roblox.Endpoints.Urls['/catalog/html'] = 'https://web.archive.org/web/20160429035611/https://search.sitetest3.bladeitter.cf/catalog/html';
Roblox.Endpoints.Urls['/catalog/json'] = 'https://web.archive.org/web/20160429035611/https://search.sitetest3.bladeitter.cf/catalog/json';
Roblox.Endpoints.Urls['/catalog/contents'] = 'https://web.archive.org/web/20160429035611/https://search.sitetest3.bladeitter.cf/catalog/contents';
Roblox.Endpoints.Urls['/catalog/lists.aspx'] = 'https://web.archive.org/web/20160429035611/https://search.sitetest3.bladeitter.cf/catalog/lists.aspx';
Roblox.Endpoints.Urls['/asset-hash-thumbnail/image'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-hash-thumbnail/image';
Roblox.Endpoints.Urls['/asset-hash-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-hash-thumbnail/json';
Roblox.Endpoints.Urls['/asset-thumbnail-3d/json'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-thumbnail-3d/json';
Roblox.Endpoints.Urls['/asset-thumbnail/image'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-thumbnail/image';
Roblox.Endpoints.Urls['/asset-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-thumbnail/json';
Roblox.Endpoints.Urls['/asset-thumbnail/url'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset-thumbnail/url';
Roblox.Endpoints.Urls['/asset/request-thumbnail-fix'] = 'https://web.archive.org/web/20160429035611/https://assetgame.sitetest3.bladeitter.cf/asset/request-thumbnail-fix';
Roblox.Endpoints.Urls['/avatar-thumbnail-3d/json'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/avatar-thumbnail-3d/json';
Roblox.Endpoints.Urls['/avatar-thumbnail/image'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/avatar-thumbnail/image';
Roblox.Endpoints.Urls['/avatar-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/avatar-thumbnail/json';
Roblox.Endpoints.Urls['/avatar-thumbnails'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/avatar-thumbnails';
Roblox.Endpoints.Urls['/avatar/request-thumbnail-fix'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/avatar/request-thumbnail-fix';
Roblox.Endpoints.Urls['/bust-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/bust-thumbnail/json';
Roblox.Endpoints.Urls['/group-thumbnails'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/group-thumbnails';
Roblox.Endpoints.Urls['/groups/getprimarygroupinfo.ashx'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/groups/getprimarygroupinfo.ashx';
Roblox.Endpoints.Urls['/headshot-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/headshot-thumbnail/json';
Roblox.Endpoints.Urls['/item-thumbnails'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/item-thumbnails';
Roblox.Endpoints.Urls['/outfit-thumbnail/json'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/outfit-thumbnail/json';
Roblox.Endpoints.Urls['/place-thumbnails'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/place-thumbnails';
Roblox.Endpoints.Urls['/thumbnail/asset/'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/asset/';
Roblox.Endpoints.Urls['/thumbnail/avatar-headshot'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/avatar-headshot';
Roblox.Endpoints.Urls['/thumbnail/avatar-headshots'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/avatar-headshots';
Roblox.Endpoints.Urls['/thumbnail/user-avatar'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/user-avatar';
Roblox.Endpoints.Urls['/thumbnail/resolve-hash'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/resolve-hash';
Roblox.Endpoints.Urls['/thumbnail/place'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/place';
Roblox.Endpoints.Urls['/thumbnail/get-asset-media'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/get-asset-media';
Roblox.Endpoints.Urls['/thumbnail/remove-asset-media'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/remove-asset-media';
Roblox.Endpoints.Urls['/thumbnail/set-asset-media-sort-order'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/set-asset-media-sort-order';
Roblox.Endpoints.Urls['/thumbnail/place-thumbnails'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/place-thumbnails';
Roblox.Endpoints.Urls['/thumbnail/place-thumbnails-partial'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail/place-thumbnails-partial';
Roblox.Endpoints.Urls['/thumbnail_holder/g'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/thumbnail_holder/g';
Roblox.Endpoints.Urls['/users/{id}/profile'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/users/{id}/profile';
Roblox.Endpoints.Urls['/service-workers/push-notifications'] = 'https://web.archive.org/web/20160429035611/https://www.sitetest3.bladeitter.cf/service-workers/push-notifications';
Roblox.Endpoints.addCrossDomainOptionsToAllRequests = true;
</script>
<script type="text/javascript">
if (typeof(Roblox) === "undefined") { Roblox = {}; }
Roblox.Endpoints = Roblox.Endpoints || {};
Roblox.Endpoints.Urls = Roblox.Endpoints.Urls || {};
</script>
</head>
<body id="rbx-body" class="" data-performance-relative-value="0.5" data-internal-page-name="" data-send-event-percentage="0.01">
 
    <div id="roblox-linkify" data-enabled="true" data-regex="(https?\:\/\/)?(?:www\.)?([a-z0-9\-]{2,}\.)*(((m|de|www|web|api|blog|wiki|help|corp|polls|bloxcon|developer|devforum|forum)\.roblox\.com|robloxlabs\.com)|(www\.shoproblox\.com))((\/[A-Za-z0-9-+&amp;@#\/%?=~_|!:,.;]*)|(\b|\s))" data-regex-flags="gm"></div>
<div id="image-retry-data" data-image-retry-max-times="10" data-image-retry-timer="1500">
</div>
<div id="http-retry-data" data-http-retry-max-timeout="8000" data-http-retry-base-timeout="1000">
</div>
    <script type="text/javascript">Roblox.XsrfToken.setToken('iP2pMh68LQs2');</script>
 
    <script type="text/javascript">
        if (top.location != self.location) {
            top.location = self.location.href;
        }
    </script>
  
<style type="text/css">
    
</style>
<form name="aspnetForm" method="post" action="https://rb16.ct8.pl/Badges.aspx" id="aspnetForm" class="nav-container no-gutter-ads">
<div>
<input type="hidden" name="__EVENTTARGET" id="__EVENTTARGET" value=""/>
<input type="hidden" name="__EVENTARGUMENT" id="__EVENTARGUMENT" value=""/>
<input type="hidden" name="__VIEWSTATE" id="__VIEWSTATE" value="TnqJfYKtt10mlmG40JldK+jkF9Ms5PY+TFIrt3pzUTG9e2V3IxP0bD4dSYxMChAhrg9Mla9U/+CzhZ+OthPOqhqs+u6/1S7ISxwK10lIg2eIvgvIMmn3JFZiXu0B0gRiC3wGX1aZxk75CXfISxv1wRFV2z+jJhXzG4b+MijIs8j+68el6RqChavFAIYkYBoRayRtMxiq2N/yFD4NTOvj5ZxIHuFSMtmMOP/SWewKWhOhxWODd0ghyUYdRbA8HomREKNWlKwPwiovUbkN6CmMdXnTXYjznmzsCwzCvXIrN0VahdnTSJ9mkex8p2zHZN+rqt01czDnx8/aUnwmxzr5t15rVlCfE4YjzqBAfQnO0NTIGZkkE1iDjZsqgvR3DOD2c2HoeHzDnEPdUVWhWYRBaPtQo48rMxXlHzPaoLTTT9s71gxY3S4BpN0hBTlMVMEjBT5oO990HRfp68X5qtdFzxI/m4zNxbtVaIjhY3KH9/sV+Ii7Z3bP4bTJTIXOU8TAEhlSEYHDvxBE82EIIfeBih7bI33UHLyZ0KPyPesr4w/apFjlsbuR224oc65e2MCjHdlpDsgYwwVL0MiwWRhfZCn1apgW4zO8mbqqLoeeOYTzpusyPB9ttJG2blZt7X3Nt6kK/5DO7LrcSz5l/W5UE3qNb21tzTrefw/qOH7lGMecFoQ3ic9xqXWaggqT42Z3vabUWsm2P4cg14dMwxkXN995Kc66azUOz6XbGEoHt3zh/fgbrgqFJD4f+OiGWqdXiuV28OaXwRgvWY7mO/jr00ja3SY="/>
</div>

<script type="text/javascript">
//<![CDATA[
var theForm = document.forms['aspnetForm'];
if (!theForm) {
    theForm = document.aspnetForm;
}
function __doPostBack(eventTarget, eventArgument) {
    if (!theForm.onsubmit || (theForm.onsubmit() != false)) {
        theForm.__EVENTTARGET.value = eventTarget;
        theForm.__EVENTARGUMENT.value = eventArgument;
        theForm.submit();
    }
}
//]]>
</script>


<script src="https://ajax.aspnetcdn.com/ajax/4.5.1/1/WebForms.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
window.WebForm_PostBackOptions||document.write('<script type="text/javascript" src="/WebResource.axd?d=pynGkmcFUV13He1Qd6_TZH6GgOgBQtqMPCPjRUnhj_pzNesAXKuAdu2pj-Sq-3JDJIgwEw2&amp;t=635589219571259667"><\/script>');//]]>
</script>



<script src="https://ajax.aspnetcdn.com/ajax/4.5.1/1/MicrosoftAjax.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
(window.Sys && Sys._Application && Sys.Observer)||document.write('<script type="text/javascript" src="/ScriptResource.axd?d=uHIkleVeDJf4xS50Krz-yA3kt4iEPLwQOcXDJXuiLb543xmSxgoBWyWb-0CTRrqRXPsCyYHFJoMX6TPqspOUhmvwRxW7JGKByJCuSKPDJkedBK4vZ68d-hQEQYwPVMjKP6tsCULlkgnx_6P0HwSsu1ZPvc01&t=ffffffff805766b3"><\/script>');//]]>
</script>

<script src="https://ajax.aspnetcdn.com/ajax/4.5.1/1/MicrosoftAjaxWebForms.js" type="text/javascript"></script>
<script type="text/javascript">
//<![CDATA[
(window.Sys && Sys.WebForms)||document.write('<script type="text/javascript" src="/ScriptResource.axd?d=Jw6tUGWnA15YEa3ai3FadCEDqusVaOyrhfy39auVd1FmNPcggz_w8ujNbCmSe3d-g1mfv3ai8xe7-2Ze2qr2BxMVxfFYswV1Y4rdnmWJF2uUrOEaDJiBEGKAzXrJcfxb_Yfc2xbZMZu9pLQP2d6b-KwvlK01&t=ffffffff805766b3"><\/script>');//]]>
</script>

<script src="/ScriptResource.axd?d=IlNPt_H8dGH-q7NoURxVyUbBBzZWrf5JHnku84lTMt4WO5vtmPJTfDOq0elV8xJbOtWY3mqwSzvRHu4Cajkr5QU1uHkUBmej6LzdhSdgGmihf7J68R3IA-z9NgNt3db-24npjiTxbtvM0LHhJa14_AeGd70rD6-FEFMF10lMWqS8wkVvT5jOMKThIiMgnq36WKMI8P25hk_XYRg4PJkroIAzsd01" type="text/javascript"></script>
<div>

  <input type="hidden" name="__VIEWSTATEGENERATOR" id="__VIEWSTATEGENERATOR" value="8D20B63A"/>
</div>
    <div id="fb-root">
    </div>
    <script type="text/javascript">
//<![CDATA[
Sys.WebForms.PageRequestManager._initialize('ctl00$ScriptManager', 'aspnetForm', [], [], [], 90, 'ctl00');
//]]>
</script>

    
         
    
    
    

<div class="modalPopup unifiedModal smallModal shop-modal shop-modal-item" data-modal-handle="shop-confirmation" style="display: none;">
    <div class="shop-modal-item-right">

    </div>
    <div class="shop-modal-item-left">
        <h2>
            You are about to visit<br/>our shopping site
        </h2>
        <div class="body-text">
            You will be redirected to the shopping<br/>site. Please note that you must be 18<br/> or over to buy online.
        </div>
        <div class="controls">
            <a id="rbx-shopping-close-btn" class="text-link btn-shopping-close">Close</a>
            <div id="rbx-continue-shopping-btn" class="btn btn-medium btn-neutral btn-secondary-xs btn-more btn-continue-shopping">Continue to Shop</div>
        </div>
        <div class="text-date-hint fine-print">
            The shop is not part of sitetest3.bladeitter.cf and is governed by a separate <a class="text-link" href="https://www.myplay.com/direct/cookie-policy?origin=desktop&amp;permalink=shoproblox" target="_blank">privacy policy</a>.
        </div>
    </div>
</div>



<script type="text/javascript">
    (function() {
        if (Roblox && Roblox.Performance) {
            Roblox.Performance.setPerformanceMark("navigation_end");
        }
    })();
</script>


        <div id="navContent" class="nav-content"><div class="nav-content-inner">
    <div id="MasterContainer">
        

<script type="text/javascript">
    $(function(){
        function trackReturns() {
            function dayDiff(d1, d2) {
                return Math.floor((d1-d2)/86400000);
            }
            if (!localStorage) {
                return false;
            }

            var cookieName = 'RBXReturn';
            var cookieOptions = {expires:9001};
            var cookieStr = localStorage.getItem(cookieName) || "";
            var cookie = {};

            try {
                cookie = JSON.parse(cookieStr);
            } catch (ex) {
                // busted cookie string from old previous version of the code
            }

            try {
                if (typeof cookie.ts === "undefined" || isNaN(new Date(cookie.ts))) {
                    localStorage.setItem(cookieName, JSON.stringify({ ts: new Date().toDateString() }));
                    return false;
                }
            } catch (ex) {
                return false;
            }

            var daysSinceFirstVisit = dayDiff(new Date(), new Date(cookie.ts));
            if (daysSinceFirstVisit == 1 && typeof cookie.odr === "undefined") {
                RobloxEventManager.triggerEvent('rbx_evt_odr', {});
                cookie.odr = 1;
            }
            if (daysSinceFirstVisit >= 1 && daysSinceFirstVisit <= 7 && typeof cookie.sdr === "undefined") {
                RobloxEventManager.triggerEvent('rbx_evt_sdr', {});
                cookie.sdr = 1;
            }
            try {
                localStorage.setItem(cookieName, JSON.stringify(cookie));
            } catch (ex) {
                return false;
            }
        }

        GoogleListener.init();


    
        RobloxEventManager.initialize(true);
        RobloxEventManager.triggerEvent('rbx_evt_pageview');
        trackReturns();
        

    
        RobloxEventManager._idleInterval = 450000;
        RobloxEventManager.registerCookieStoreEvent('rbx_evt_initial_install_start');
        RobloxEventManager.registerCookieStoreEvent('rbx_evt_ftp');
        RobloxEventManager.registerCookieStoreEvent('rbx_evt_initial_install_success');
        RobloxEventManager.registerCookieStoreEvent('rbx_evt_fmp');
        RobloxEventManager.startMonitor();
        

    });

</script>



        <script type="text/javascript">Roblox.FixedUI.gutterAdsEnabled=false;</script>

        

        <div id="Container">
            
            
        </div>

    
        
        <noscript><div class="alert-info"><h5>Please enable Javascript to use all the features on this site.</h5></div></noscript>
        
        
        
        
        
        
    <div id="AdvertisingLeaderboard">
        

<iframe name="Roblox_Item_Top_728x90" allowtransparency="true" frameborder="0" height="110" scrolling="no" src="/userads/3" width="728" data-js-adtype="iframead"></iframe>

    </div>

        
        <div id="BodyWrapper">
            
            <div id="RepositionBody">
                <div id="Body" class="">
                    
    <div id="BadgesContainer" class="text">
    <h1>Badges</h1>
        <div class="BadgeCategory">
            <h2>Membership Badges</h2>
            <ul>
                    <li id="Badge18" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/6c2a598114231066a386fa716ac099c4.png" alt="Welcome To The Club" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Welcome To The Club Badge</h3>
                                <p class="notranslate">This badge is awarded to players who have ever belonged to the illustrious Builders Club. These players are part of a long tradition of ROBLOX greatness.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge11" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/3b3ab51727ad660e1569cb53e0b2d4a5.png" alt="Builders Club" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Builders Club Badge</h3>
                                <p class="notranslate">Members of the illustrious Builders Club display this badge proudly. The Builders Club is a paid premium service. Members receive several benefits: they get ten places on their account instead of one, they earn a daily income of 15 ROBUX, they can sell their creations to others in the ROBLOX Catalog, they get the ability to browse the web site without external ads, and they receive the exclusive Builders Club construction hat.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge15" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/61f5f43c05222fc2ce06b9983d4e1107.png" alt="Turbo Builders Club" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Turbo Builders Club Badge</h3>
                                <p class="notranslate">Members of the exclusive Turbo Builders Club are some of the most dedicated ROBLOXians. The Turbo Builders Club is a paid premium service. Members receive many of the benefits received in the regular Builders Club, in addition to a few more exclusive upgrades: they get twenty-five places on their account instead of ten from regular Builders Club, they earn a daily income of 35 ROBUX, they can sell their creations to others in the ROBLOX Catalog, they get the ability to browse the web site without external ads, they receive the exclusive Turbo Builders Club red site managers hat, and they receive an exclusive gear item.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge16" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/7df6357ab1eb2dcf5267d2c5184732ab.png" alt="Outrageous Builders Club" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Outrageous Builders Club Badge</h3>
                                <p class="notranslate">Members of Outrageous Builders Club are VIP ROBLOXians. They are the cream of the crop. The Outrageous Builders Club is a paid premium service. Members receive 100 places, 100 groups, 60 ROBUX per day, unlock the Outrageous website theme, and many other benefits.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
            </ul>
        </div>
        <div class="BadgeCategory">
            <h2>Community Badges</h2>
            <ul>
                    <li id="Badge1" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/def12ef9c8501334987a642eb11b7c91.png" alt="Administrator" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Administrator Badge</h3>
                                <p class="notranslate">This badge identifies an account as belonging to a Roblox administrator. Only official Roblox administrators will possess this badge. If someone claims to be an admin, but does not have this badge, they are potentially trying to mislead you. If this happens, please report abuse and we will delete the imposter&#39;s account.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge12" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/b7e6cabb5a1600d813f5843f37181fa3.png" alt="Veteran" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Veteran Badge</h3>
                                <p class="notranslate">This badge recognizes members who have played ROBLOX for one year or more. They are stalwart community members who have stuck with us over countless releases, and have helped shape ROBLOX into the game that it is today. These medalists are the true steel, the core of the Robloxian history ... and its future.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge2" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/5eb20917cf530583e2641c0e1f7ba95e.png" alt="Friendship" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Friendship Badge</h3>
                                <p class="notranslate">This badge is given to players who have embraced the Roblox community and have made at least 20 friends. People who have this badge are good people to know and can probably help you out if you are having trouble.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge14" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/b853909efc7fdcf590363d01f5894f09.png" alt="Ambassador" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Ambassador Badge</h3>
                                <p class="notranslate">This badge was awarded during the Ambassador Program, which ran from 2009 to 2012. It has been retired and is no longer attainable.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge8" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/01044aca1d917eb20bfbdc5e25af1294.png" alt="Inviter" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Inviter Badge</h3>
                                <p class="notranslate">This badge was awarded during the Inviter Program, which ran from 2009 to 2013. It has been retired and is no longer attainable.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
            </ul>
        </div>
        <div class="BadgeCategory">
            <h2>Developer Badges</h2>
            <ul>
                    <li id="Badge6" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/b66bc601e2256546c5dd6188fce7a8d1.png" alt="Homestead" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Homestead Badge</h3>
                                <p class="notranslate">The homestead badge is earned by having your personal place visited 100 times. Players who achieve this have demonstrated their ability to build cool things that other Robloxians were interested enough in to check out. Get a jump-start on earning this reward by inviting people to come visit your place.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge7" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/49f3d30f5c16a1c25ea0f97ea8ef150e.png" alt="Bricksmith" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Bricksmith Badge</h3>
                                <p class="notranslate">The Bricksmith badge is earned by having a popular personal place. Once your place has been visited 1000 times, you will receive this award. Robloxians with Bricksmith badges are accomplished builders who were able to create a place that people wanted to explore a thousand times. They no doubt know a thing or two about putting bricks together.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge17" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/45710972c9c8d556805f8bee89389648.png" alt="Official Model Maker" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Official Model Maker Badge</h3>
                                <p class="notranslate">This badge is awarded to players whose creations are so awesome, ROBLOX endorsed them. Owners of this badge probably have great scripting and building skills.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
            </ul>
        </div>
        <div class="BadgeCategory">
            <h2>Gamer Badges</h2>
            <ul>
                    <li id="Badge3" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/8d77254fc1e6d904fd3ded29dfca28cb.png" alt="Combat Initiation" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Combat Initiation Badge</h3>
                                <p class="notranslate">This badge was granted when a player scored 10 victories in games that use classic combat scripts. It was retired Summer 2015 and is no longer attainable.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge4" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/0a010c31a8b482731114810590553be3.png" alt="Warrior" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Warrior Badge</h3>
                                <p class="notranslate">This badge was granted when a player scored 100 or more victories in games that use classic combat scripts. It was retired Summer 2015 and is no longer attainable.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
                    <li id="Badge5" class="divider-bottom">
                        <div class="BadgePadding">&nbsp;</div>
                        <div class="BadgeContent">
                            <div class="BadgeImage">
                                <img src="https://images.rbxcdn.com/139a7b3acfeb0b881b93a40134766048.png" alt="Bloxxer" width="75" height="75"/>
                            </div>
                            <div class="BadgeDescription">
                                <h3>Bloxxer Badge</h3>
                                <p class="notranslate">This badge was granted when a player scored at least 250 victories, and fewer than 250 wipeouts, in games that use classic combat scripts. It was retired Summer 2015 and is no longer attainable.</p>
                            </div>
                            <div style="clear:both"></div>
                        </div>
                    </li>
            </ul>
        </div>
</div>

<script type="text/javascript">
    $(function () {
        // Has a hash, highdark that element
        if (window.location.hash.length != 0) {
            var highdark = $(window.location.hash + ' .BadgeContent');
            highdark.addClass('selectedInitial');
            setTimeout(function() {
                highdark.addClass("selectedFadeOut");
            }, 0);
        }
    });
</script>

                    <div style="clear:both"></div>
                </div>
            </div>
        </div> 
        </div>
        
            




        
        </div></div>
    </div>
    
        <script type="text/javascript">
            function urchinTracker() { };
            GoogleAnalyticsReplaceUrchinWithGAJS = true;
        </script>
    

    </form>
    
    
    

    <style>
        #win_firefox_install_img .activation {
        }

        #win_firefox_install_img .installation {
            width: 869px;
            height: 331px;
        }

        #mac_firefox_install_img .activation {
        }

        #mac_firefox_install_img .installation {
            width: 250px;
        }

        #win_chrome_install_img .activation {
        }

        #win_chrome_install_img .installation {
        }

        #mac_chrome_install_img .activation {
            width: 250px;
        }

        #mac_chrome_install_img .installation {
        }
    </style>
    <div id="InstallationInstructions" class="modalPopup blueAndWhite" style="display:none;overflow:hidden">
        <a id="CancelButton2" onclick="return Roblox.Client._onCancel();" class="ImageButton closeBtnCircle_35h ABCloseCircle"></a>
        <div style="padding-bottom:10px;text-align:center">
            <br/><br/>
        </div>
    </div>



<div id="pluginObjDiv" style="height:1px;width:1px;visibility:hidden;position: absolute;top: 0;"></div>
<iframe id="downloadInstallerIFrame" style="visibility:hidden;height:0;width:1px;position:absolute"></iframe>

<script type="text/javascript" src="https://js.rbxcdn.com/1ba208cf31fb5a6a592b902955c8770b.js"></script>

<script type="text/javascript">
    Roblox.Client._skip = '/install/unsupported.aspx';
    Roblox.Client._CLSID = '';
    Roblox.Client._installHost = '';
    Roblox.Client.ImplementsProxy = false;
    Roblox.Client._silentModeEnabled = false;
    Roblox.Client._bringAppToFrontEnabled = false;
    Roblox.Client._currentPluginVersion = '';
    Roblox.Client._eventStreamLoggingEnabled = false;

        
        Roblox.Client._installSuccess = function() {
            if(GoogleAnalyticsEvents){
                GoogleAnalyticsEvents.ViewVirtual('InstallSuccess');
                GoogleAnalyticsEvents.FireEvent(['Plugin','Install Success']);
                if (Roblox.Client._eventStreamLoggingEnabled && typeof Roblox.GamePlayEvents != "undefined") {
                    Roblox.GamePlayEvents.SendInstallSuccess(Roblox.Client._launchMode, play_placeId);
                }
            }
        }
        
    </script>


<div id="PlaceLauncherStatusPanel" style="display:none;width:300px" data-new-plugin-events-enabled="True" data-event-stream-for-plugin-enabled="True" data-event-stream-for-protocol-enabled="True" data-is-game-launch-interface-enabled="False" data-is-protocol-handler-launch-enabled="False" data-is-user-logged-in="False" data-os-name="Unknown" data-protocol-name-for-client="roblox-player" data-protocol-name-for-studio="roblox-studio" data-protocol-url-includes-launchtime="true" data-protocol-detection-enabled="true">
    <div class="modalPopup blueAndWhite PlaceLauncherModal" style="min-height: 160px">
        <div id="Spinner" class="Spinner" style="padding:20px 0;">
            <img src="https://images.rbxcdn.com/e998fb4c03e8c2e30792f2f3436e9416.gif" height="32" width="32" alt="Progress"/>
        </div>
        <div id="status" style="min-height:40px;text-align:center;margin:5px 20px">
            <div id="Starting" class="PlaceLauncherStatus MadStatusStarting" style="display:block">
                Starting Roblox...
            </div>
            <div id="Waiting" class="PlaceLauncherStatus MadStatusField">Connecting to Players...</div>
            <div id="StatusBackBuffer" class="PlaceLauncherStatus PlaceLauncherStatusBackBuffer MadStatusBackBuffer"></div>
        </div>
        <div style="text-align:center;margin-top:1em">
            <input type="button" class="Button CancelPlaceLauncherButton translate" value="Cancel"/>
        </div>
    </div>
</div>
<div id="ProtocolHandlerStartingDialog" style="display:none;">
    <div class="modalPopup ph-modal-popup">
        <div class="ph-modal-header">

        </div>
        <div class="ph-logo-row">
            <img src="https://images.rbxcdn.com/e060b59b57fdcc7874c820d13fdcee71.svg" width="90" height="90" alt="R"/>
        </div>
        <div class="ph-areyouinstalleddialog-content">
            <p class="larger-font-size">
                ROBLOX is now loading. Get ready to play!
            </p>
            <div class="ph-startingdialog-spinner-row">
                <img src="https://images.rbxcdn.com/4bed93c91f909002b1f17f05c0ce13d1.gif" width="82" height="24"/>
            </div>
        </div>
    </div>
</div>
<div id="ProtocolHandlerAreYouInstalled" style="display:none;">
    <div class="modalPopup ph-modal-popup">
        <div class="ph-modal-header">
            <span class="icon-close simplemodal-close"></span>
        </div>
        <div class="ph-logo-row">
            <img src="https://images.rbxcdn.com/e060b59b57fdcc7874c820d13fdcee71.svg" width="90" height="90" alt="R"/>
        </div>
        <div class="ph-areyouinstalleddialog-content">
            <p class="larger-font-size">
                You're moments away from getting into the game!
            </p>
            <div>
                <button type="button" class="btn btn-primary-md" id="ProtocolHandlerInstallButton">
                    Download and Install ROBLOX
                </button>
            </div>
            <div class="small">
                <a href="https://en.help.rb16.ct8.pl/hc/en-us/articles/204473560" class="text-name" target="_blank">Click here for help</a>
            </div>

        </div>
    </div>
</div>
<div id="ProtocolHandlerClickAlwaysAllowed" class="ph-clickalwaysallowed" style="display:none;">
    <p class="larger-font-size">
        <span class="icon-moreinfo"></span>
        Check <b>Remember my choice</b> and click <img src="https://images.rbxcdn.com/7c8d7a39b4335931221857cca2b5430b.png" alt="Launch Application"/>  in the dialog box above to join games faster in the future!
    </p>
</div>


    <div id="videoPrerollPanel" style="display:none">
        <div id="videoPrerollTitleDiv">
            Gameplay sponsored by:
        </div>
        <div id="videoPrerollMainDiv"></div>
        <div id="videoPrerollCompanionAd"></div>
        <div id="videoPrerollLoadingDiv">
            Loading <span id="videoPrerollLoadingPercent">0%</span> - <span id="videoPrerollMadStatus" class="MadStatusField">Starting game...</span><span id="videoPrerollMadStatusBackBuffer" class="MadStatusBackBuffer"></span>
            <div id="videoPrerollLoadingBar">
                <div id="videoPrerollLoadingBarCompleted">
                </div>
            </div>
        </div>
        <div id="videoPrerollJoinBC">
            <span>Get more with Builders Club!</span>
            <a href="/premium/membership?ctx=preroll" target="_blank" class="btn-medium btn-primary" id="videoPrerollJoinBCButton">Join Builders Club</a>
        </div>
    </div>
    <script type="text/javascript">
        $(function () {
            if (Roblox.VideoPreRoll) {
                Roblox.VideoPreRoll.showVideoPreRoll = false;
                Roblox.VideoPreRoll.isPrerollShownEveryXMinutesEnabled = true;
                Roblox.VideoPreRoll.loadingBarMaxTime = 33000;
                Roblox.VideoPreRoll.videoOptions.key = "robloxcorporation"; 
                    Roblox.VideoPreRoll.videoOptions.categories = "AgeUnknown,GenderUnknown";
                                     Roblox.VideoPreRoll.videoOptions.id = "games";
                Roblox.VideoPreRoll.videoLoadingTimeout = 11000;
                Roblox.VideoPreRoll.videoPlayingTimeout = 41000;
                Roblox.VideoPreRoll.videoLogNote = "NotWindows";
                Roblox.VideoPreRoll.logsEnabled = true;
                Roblox.VideoPreRoll.excludedPlaceIds = "32373412";
                Roblox.VideoPreRoll.adTime = 15;
                    
                Roblox.VideoPreRoll.specificAdOnPlacePageEnabled = true;
                Roblox.VideoPreRoll.specificAdOnPlacePageId = 192800;
                Roblox.VideoPreRoll.specificAdOnPlacePageCategory = "stooges";
                
                                    
                Roblox.VideoPreRoll.specificAdOnPlacePage2Enabled = true;
                Roblox.VideoPreRoll.specificAdOnPlacePage2Id = 2370766;
                Roblox.VideoPreRoll.specificAdOnPlacePage2Category = "lego";
                
                $(Roblox.VideoPreRoll.checkEligibility);
            }
        });
    </script>


<div id="GuestModePrompt_BoyGirl" class="Revised GuestModePromptModal" style="display:none;">
    <div class="simplemodal-close">
        <a class="ImageButton closeBtnCircle_20h" style="cursor: pointer; margin-left:455px;top:7px; position:absolute;"></a>
    </div>
    <div class="Title">
        Choose Your Avatar
    </div>
    <div style="min-height: 275px; background-color: white;">
        <div style="clear:both; height:25px;"></div>

        <div style="text-align: center;">
            <div class="VisitButtonsGuestCharacter VisitButtonBoyGuest" style="float:left; margin-left:45px;"></div>
            <div class="VisitButtonsGuestCharacter VisitButtonGirlGuest" style="float:right; margin-right:45px;"></div>
        </div>
        <div style="clear:both; height:25px;"></div>
        <div class="RevisedFooter">
            <div style="width:200px;margin:10px auto 0 auto;">
                <a href="/?returnUrl=https%3A%2F%2Fwww.rb16.ct8.pl%2FBadges.aspx"><div class="RevisedCharacterSelectSignup"></div></a>
                <a class="HaveAccount" href="/newlogin?returnUrl=https%3A%2F%2Fwww.rb16.ct8.pl%2FBadges.aspx">I have an account</a>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
    function checkRobloxInstall() {
                 window.location = '/install/unsupported.aspx'; return false;
    }

</script>

<script type="text/javascript">
    var Roblox = Roblox || {};
    Roblox.UpsellAdModal = Roblox.UpsellAdModal || {};

    Roblox.UpsellAdModal.Resources = {
        //<sl:translate>
        title: "Remove Ads Like This",
        body: "Builders Club members do not see external ads like these.",
        accept: "Upgrade Now",
        decline: "No, thanks"
        //</sl:translate>
    };
</script>  

<div class="ConfirmationModal modalPopup unifiedModal smallModal" data-modal-handle="confirmation" style="display:none;">
    <a class="genericmodal-close ImageButton closeBtnCircle_20h"></a>
    <div class="Title"></div>
    <div class="GenericModalBody">
        <div class="TopBody">
            <div class="ImageContainer roblox-item-image" data-image-size="small" data-no-overlays data-no-click>
                <img class="GenericModalImage" alt="generic image"/>
            </div>
            <div class="Message"></div>
        </div>
        <div class="ConfirmationModalButtonContainer">
            <a href id="roblox-confirm-btn"><span></span></a>
            <a href id="roblox-decline-btn"><span></span></a>
        </div>
        <div class="ConfirmationModalFooter">
        
        </div>  
    </div>   
    <script type="text/javascript">
        Roblox = Roblox || {};
        Roblox.Resources = Roblox.Resources || {};

        //<sl:translate>
        Roblox.Resources.GenericConfirmation = {
            yes: "Yes",
            No: "No",
            Confirm: "Confirm",
            Cancel: "Cancel"
        };
        //</sl:translate>
    </script>
</div>


    
        <script>
            $(function () {
                Roblox.DeveloperConsoleWarning.showWarning();
            });
        </script>
    

    <script type="text/javascript">
        $(function () {
            Roblox.CookieUpgrader.domain = 'rb16.ct8.pl';
            Roblox.CookieUpgrader.upgrade("GuestData", { expires: Roblox.CookieUpgrader.thirtyYearsFromNow });
            Roblox.CookieUpgrader.upgrade("RBXSource", { expires: function (cookie) { return Roblox.CookieUpgrader.getExpirationFromCookieValue("rbx_acquisition_time", cookie); } });
            Roblox.CookieUpgrader.upgrade("RBXViralAcquisition", { expires: function (cookie) { return Roblox.CookieUpgrader.getExpirationFromCookieValue("time", cookie); } });
                
                Roblox.CookieUpgrader.upgrade("RBXMarketing", { expires: Roblox.CookieUpgrader.thirtyYearsFromNow });
                
                            
                Roblox.CookieUpgrader.upgrade("RBXSessionTracker", { expires: Roblox.CookieUpgrader.fourHoursFromNow });
                
                            
                Roblox.CookieUpgrader.upgrade("RBXEventTrackerV2", {expires: Roblox.CookieUpgrader.thirtyYearsFromNow});
                
        });
    </script>
    <script>
        var _comscore = _comscore || [];
        _comscore.push({ c1: "2", c2: "6035605", c3: "", c4: "", c15: "" });

        (function() {
            var s = document.createElement("script"), el = document.getElementsByTagName("script")[0];
            s.async = true;
            s.src = (document.location.protocol == "https:" ? "https://sb" : "https://b") + ".scorecardresearch.com/beacon.js";
            el.parentNode.insertBefore(s, el);
        })();
    </script>
    <noscript>
        <img src="https://b.scorecardresearch.com/p?c1=2&amp;c2=&amp;c3=&amp;c4=&amp;c5=&amp;c6=&amp;c15=&amp;cv=2.0&amp;cj=1"/>
    </noscript>

</body>                
</html>







