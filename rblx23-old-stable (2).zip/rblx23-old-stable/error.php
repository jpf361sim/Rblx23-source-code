<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "https://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">
<html xmlns="https://www.w3.org/1999/xhtml">
<head>
    <link rel="shortcut icon" type="image/x-icon" href="https://static.ct8.pl/favicon.ico" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="description" content="Website blocked" />
    <title>Serv00.com - Free Website Hosting - Error 50000000000000 Website killed its self</title>

    <meta name="robots" content="all" />
    <style type="text/css">

    body {
        background-image: linear-gradient(141deg, #3f282a 0%, #333 71%, #222 100%) !important;
        background-attachment: fixed;
        font-size: 12px;
        color: #333;
        font-family: Arial, verdana, tahoma;
        padding: 0;
        margin: 0;
    }


#main {
    background: none repeat scroll 0 0 #FFFFFF;
    box-shadow: 0 0 40px #00275A;
    padding-bottom: 20px;
    padding-top: 20px;
    width: 100%;
    margin-top: 65px;
}


#mainwrapper {
    display: table;
    margin: 0 auto;
    width: 950px;
}

    h1 {
        color: #FF55FF;
        text-shadow: 1px 1px 3px #999;
        font-weight: normal;
        font-size: 35px;
    }

    p.small {
        color: #888;
    }

    a {
        text-decoration: none;
        color: #FF55FF;
    }

h2 {
    color: #EE6628;
    margin-bottom: 10px;
}

h2 {
    color: #EE6628;
    font-size: 44px;
    text-shadow: 1px 1px 2px #A7A7A7;
}


h3 {
    color: #CD00CD;
    font-size: 25px;
    text-shadow: 1px 1px 2px #D4D4D4;
    margin-top: 0px;
}

div.ads img {
    margin: 10px;
}

hr {
    border: 0;
    border-top: 1px dotted #BFBFBF;
}

span.grey {
    color: #D9D9D9;
}
    </style>
</head>
<body>
    <div id="main">
        <div id="mainwrapper">
            <h2>Error 50000000000000</h2>
            <h3>Website killed its self</h3>
            <p>This page has killed it self from overload</a>.</p>

            <p class="small">If you have any questions <a href="https://www.serv00.com/contact" title="Serv00.com - contact">contact us</a>.</p>
            <br />
            <hr />
<!--            <div class="ads">
            <a title="MyDevil.net - Doskonały hosting dla biznesu" href="https://www.mydevil.net"><img src="https://www.mydevil.net/static/assets/logo.png" alt="MyDevil.net - Doskonały hosting dla biznesu" /></a>
            </div> -->
            <span class="grey">server: s0.serv00.com</span>
        </div>
    </div>
</body>
</html>