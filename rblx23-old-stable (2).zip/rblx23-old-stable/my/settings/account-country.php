<?php
$jsonData = '{
    "countryName": "test",
    "localizedName": "Italy",
    "countryId": 110,
    "success": true,
    "errorMessage": null
}';

// Decode JSON data into PHP associative array

// Output the JSON response
echo $jsonData;