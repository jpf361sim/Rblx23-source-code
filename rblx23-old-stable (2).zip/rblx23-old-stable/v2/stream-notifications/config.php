<?php
$server_name = "mysql0.serv00.com";
$db_name = "m4486_st3";
$user_sql = "m4486_root";
$user_pass = "xzNsO(CE^D#V7T4KjhlG";

$encryption_key = "+[(j%j,\_eFLF~(x:94a";
//todo
?>















