{
    "HasPurchase": false,
    "HasSale": false,
    "HasAffiliateSale": false,
    "HasGroupPayout": false,
    "HasCurrencyPurchase": true,
    "HasTradeRobux": false,
    "HasPremiumStipend": true,
    "HasEngagementPayout": false,
    "HasGroupEngagementPayout": false,
    "HasAdSpend": false,
    "HasDevEx": false,
    "HasPendingRobux": true,
    "HasIndividualToGroup": false,
    "HasCSAdjustment": false,
    "HasAdsRevsharePayout": false,
    "HasGroupAdsRevsharePayout": false
}