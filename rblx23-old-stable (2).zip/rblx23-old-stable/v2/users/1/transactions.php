{
    "previousPageCursor": null,
    "nextPageCursor": "eyJrZXkiOjEwMCwic29ydE9yZGVyIjoiQXNjIiwicGFnaW5nRGlyZWN0aW9uIjoiRm9yd2FyZCIsInBhZ2VOdW1iZXIiOjIsImRpc2NyaW1pbmF0b3IiOiJ1c2VySWQ6MjQzODY1NTI5OHRyYW5zYWN0aW9uVHlwZTpQdXJjaGFzZSIsImNvdW50IjoxMDB9CjJiZjIwMjg1OWE1ZGU1OTA2YThmYjUyY2ZjZGJmYzE2ZjY4ZTYzMGJjY2RkMWZlNzZmZDQ5YTA5ODdlNzVjYWI=",
    "data": [
        {
            "id": 31436460160,
            "idHash": "QscIBnbJTyS1VdZDeXmZ+g",
            "transactionType": "Purchase",
            "created": "2023-07-15T00:25:57.56Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 125,
                "name": "Oakley",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 31151778064,
            "idHash": "1gHZiZXV1oWT1VmcQkrFtA",
            "transactionType": "Purchase",
            "created": "2023-06-30T22:42:41.85Z",
            "isPending": false,
            "agent": {
                "id": 6639766,
                "type": "Group",
                "name": "Century Makers"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 6737970321,
                    "universeId": 2549475383,
                    "name": "Livetopia🏡 New house"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29983011759,
            "idHash": "Il3nZCk/sQ8CZ1R6ThjkzA",
            "transactionType": "Purchase",
            "created": "2023-04-26T18:08:39.21Z",
            "isPending": false,
            "agent": {
                "id": 63700903,
                "type": "User",
                "name": "Coeptus"
            },
            "details": {
                "id": 333083,
                "name": "1000 Money",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 185655149,
                    "universeId": 88070565,
                    "name": "Welcome to Bloxburg"
                }
            },
            "currency": {
                "amount": -20,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29610823508,
            "idHash": "WOXIjxC259qN2I3w8VOD6Q",
            "transactionType": "Purchase",
            "created": "2023-04-07T19:46:27.46Z",
            "isPending": false,
            "agent": {
                "id": 84182809,
                "type": "User",
                "name": "HowToRoblox"
            },
            "details": {
                "id": 6554374785,
                "name": "Animation Gui",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29609000948,
            "idHash": "Rvs6rkUp0x2iDdD0HcqsNA",
            "transactionType": "Purchase",
            "created": "2023-04-07T18:18:23.287Z",
            "isPending": false,
            "agent": {
                "id": 1831503736,
                "type": "User",
                "name": "WavaDev"
            },
            "details": {
                "id": 11295345519,
                "name": "CookieTehCheckIn System",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29122478432,
            "idHash": "/6+WPVjWvlix+yOg/CWUJQ",
            "transactionType": "Purchase",
            "created": "2023-03-12T15:01:58.26Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 979,
                "name": "Base Body - Riley",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29122388494,
            "idHash": "7wqWr6B6la/BASw2yLxEVA",
            "transactionType": "Purchase",
            "created": "2023-03-12T14:57:34.553Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 722,
                "name": "Denny",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29122382650,
            "idHash": "/NdDDflQ3bnHykCCDWsVEw",
            "transactionType": "Purchase",
            "created": "2023-03-12T14:57:17.553Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 985,
                "name": "Base Body - Parker",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29094614554,
            "idHash": "/Oo0SZ1d9ix4EWU4KBOaag",
            "transactionType": "Purchase",
            "created": "2023-03-11T13:17:20.717Z",
            "isPending": false,
            "agent": {
                "id": 14467815,
                "type": "Group",
                "name": "HyperCatz"
            },
            "details": {
                "id": 20605099,
                "name": "Skip Checkpoint",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 12418862625,
                    "universeId": 4369389881,
                    "name": "ESCAPE EVIL STEPMOM! (Obby)"
                }
            },
            "currency": {
                "amount": -25,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 29082356219,
            "idHash": "WzvSVGY4dCf2fwOCdGNqSw",
            "transactionType": "Purchase",
            "created": "2023-03-10T23:45:50.08Z",
            "isPending": false,
            "agent": {
                "id": 94607002,
                "type": "User",
                "name": "Rush"
            },
            "details": {
                "id": 10781701701,
                "name": "Black To Red Fluffy Middle Swept Hair",
                "type": "Asset"
            },
            "currency": {
                "amount": -75,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 28603372437,
            "idHash": "cjkwGiX5FH1LWa0ompe9Hw",
            "transactionType": "Purchase",
            "created": "2023-02-12T15:50:24Z",
            "isPending": false,
            "agent": {
                "id": 3049798,
                "type": "Group",
                "name": "LSPLASH"
            },
            "details": {
                "id": 14198404,
                "name": "REVIVE YOURSELF INSTANTLY",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 6516141723,
                    "universeId": 2440500124,
                    "name": "DOORS 👁️"
                }
            },
            "currency": {
                "amount": -30,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 27969574582,
            "idHash": "nfDQ6JHfOT0+YJEsLbcnjQ",
            "transactionType": "Purchase",
            "created": "2023-01-10T18:19:49.777Z",
            "isPending": false,
            "agent": {
                "id": 1055084448,
                "type": "User",
                "name": "Ericksen"
            },
            "details": {
                "id": 108733766,
                "name": "ghjkhg",
                "type": "GamePass",
                "place": {
                    "placeId": 8759961588,
                    "universeId": 3323995797,
                    "name": "80's Bar"
                }
            },
            "currency": {
                "amount": -4,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26712831807,
            "idHash": "s7o0y6968wSLjg0MxrIlFw",
            "transactionType": "Purchase",
            "created": "2022-11-05T18:04:24.89Z",
            "isPending": false,
            "agent": {
                "id": 2438655298,
                "type": "User",
                "name": "Una_Personahh"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 11476956720,
                    "universeId": 4079933819,
                    "name": "meep city copy"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26711166830,
            "idHash": "lbucbWKBaaTczEKlFe6qhQ",
            "transactionType": "Purchase",
            "created": "2022-11-05T16:48:11.887Z",
            "isPending": false,
            "agent": {
                "id": 469572865,
                "type": "User",
                "name": "nodnarb"
            },
            "details": {
                "id": 9232792265,
                "name": "Modded MM2 GUI Fix",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26632619526,
            "idHash": "P7mkXR+W59sASIr1UQY4Gw",
            "transactionType": "Purchase",
            "created": "2022-10-31T23:00:17.1Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 946,
                "name": "Stevie Standard",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26632586621,
            "idHash": "oh6PLEcAkBjlkZdxYDgAaQ",
            "transactionType": "Purchase",
            "created": "2022-10-31T22:57:04.78Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9240757332,
                "name": "Knit Sweater - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26632581100,
            "idHash": "8ftls/F3t1czdSX7XxFfFw",
            "transactionType": "Purchase",
            "created": "2022-10-31T22:56:32.817Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 10607480911,
                "name": "Paranormal Party Starter",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26560949559,
            "idHash": "Ie3PgGJxwF1hBIbiXMKGew",
            "transactionType": "Purchase",
            "created": "2022-10-28T17:20:26.69Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 3360692915,
                "name": "Tilt",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 26560947250,
            "idHash": "S89QJm20hQ9K55aqZeOSuQ",
            "transactionType": "Purchase",
            "created": "2022-10-28T17:20:17.743Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 5915779043,
                "name": "Applaud",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25974008306,
            "idHash": "0hqS99ZXU7JsZQVRnsh1HQ",
            "transactionType": "Purchase",
            "created": "2022-09-27T19:44:21.967Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 945,
                "name": "Dylan Default",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25972120374,
            "idHash": "otZ6q0fj4m33fcQXgBM2yw",
            "transactionType": "Purchase",
            "created": "2022-09-27T18:05:14.113Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 894,
                "name": "Canvas Shoes - White",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25728118131,
            "idHash": "95Plpqz6MH7PxIs/UqaeAQ",
            "transactionType": "Purchase",
            "created": "2022-09-13T23:00:34.737Z",
            "isPending": false,
            "agent": {
                "id": 7384468,
                "type": "Group",
                "name": "Roblox Arena Events"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 10767940743,
                    "universeId": 3893964208,
                    "name": "RDC 2022"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25702734112,
            "idHash": "qj+QXZqAtSGr4NRNZ+nj1g",
            "transactionType": "Purchase",
            "created": "2022-09-12T01:48:59.177Z",
            "isPending": false,
            "agent": {
                "id": 51946717,
                "type": "User",
                "name": "ThePowerOfObc"
            },
            "details": {
                "id": 139385874,
                "name": "Face #5",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25702723919,
            "idHash": "vIcT9o+WpJacKli2IarNSQ",
            "transactionType": "Purchase",
            "created": "2022-09-12T01:48:11.72Z",
            "isPending": false,
            "agent": {
                "id": 51946717,
                "type": "User",
                "name": "ThePowerOfObc"
            },
            "details": {
                "id": 139385762,
                "name": "[ Content Deleted ]",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25246297803,
            "idHash": "+URiI+nyVdv8yQUS9RwL1w",
            "transactionType": "Purchase",
            "created": "2022-08-21T16:42:30.363Z",
            "isPending": false,
            "agent": {
                "id": 378685924,
                "type": "User",
                "name": "Gamer"
            },
            "details": {
                "id": 4508836580,
                "name": "2016 Loading Screen",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25246237676,
            "idHash": "z5EKPjicUc4EHh3+vsVMvg",
            "transactionType": "Purchase",
            "created": "2022-08-21T16:39:48.053Z",
            "isPending": false,
            "agent": {
                "id": 3659905,
                "type": "User",
                "name": "csqrl"
            },
            "details": {
                "id": 127224797,
                "name": "RobloxGui (CoreGui), 21/08/2013",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25132704967,
            "idHash": "CI+ljuSMTVf8NttkyCt3cg",
            "transactionType": "Purchase",
            "created": "2022-08-16T10:43:01.423Z",
            "isPending": false,
            "agent": {
                "id": 103456922,
                "type": "User",
                "name": "Valerist"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 6068693809,
                    "universeId": 2201166997,
                    "name": "enceladus, but he's real"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25049166074,
            "idHash": "EY+CYbvBgt8O7S4TUPPqDQ",
            "transactionType": "Purchase",
            "created": "2022-08-12T13:08:56.523Z",
            "isPending": false,
            "agent": {
                "id": 1541762848,
                "type": "User",
                "name": "ilovenuggets"
            },
            "details": {
                "id": 5151649139,
                "name": "[DESC]Moon Animation Suite",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25049162705,
            "idHash": "z3AhN+rBTjTU/G5eNcRa7w",
            "transactionType": "Purchase",
            "created": "2022-08-12T13:08:42.127Z",
            "isPending": false,
            "agent": {
                "id": 502368373,
                "type": "User",
                "name": "LatainaGorlxx"
            },
            "details": {
                "id": 6284786438,
                "name": "Lobby Builder",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 25049159673,
            "idHash": "p2JEseuipeL4a5Ehhxh5WQ",
            "transactionType": "Purchase",
            "created": "2022-08-12T13:08:29.033Z",
            "isPending": false,
            "agent": {
                "id": 502368373,
                "type": "User",
                "name": "LatainaGorlxx"
            },
            "details": {
                "id": 6287105866,
                "name": "MurderMysteryKit",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24771334677,
            "idHash": "nihkrnO2LcCcvYxJ4CIQBQ",
            "transactionType": "Purchase",
            "created": "2022-07-29T23:17:39.543Z",
            "isPending": false,
            "agent": {
                "id": 509038592,
                "type": "User",
                "name": "purly"
            },
            "details": {
                "id": 6963394301,
                "name": "AvatarEditor [By Purly_Dev]",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24721488806,
            "idHash": "SAdDrL8wlDhLB+CeSHw/EQ",
            "transactionType": "Purchase",
            "created": "2022-07-27T17:11:17.89Z",
            "isPending": false,
            "agent": {
                "id": 13005515,
                "type": "Group",
                "name": "Eternos Digital"
            },
            "details": {
                "id": 9178684281,
                "name": "Unstoppable Sweatpants",
                "type": "Asset"
            },
            "currency": {
                "amount": -50,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24721082726,
            "idHash": "Bh7DUh9n+HHNExwiG/EwQg",
            "transactionType": "Purchase",
            "created": "2022-07-27T16:47:25.43Z",
            "isPending": false,
            "agent": {
                "id": 4861936,
                "type": "Group",
                "name": "Debi UGC Creations"
            },
            "details": {
                "id": 9424985776,
                "name": "Blue Smile hip hop Sweater",
                "type": "Asset"
            },
            "currency": {
                "amount": -50,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24714243109,
            "idHash": "H3OY64QDV1ovgUL7ohKN0A",
            "transactionType": "Purchase",
            "created": "2022-07-27T08:20:40.837Z",
            "isPending": false,
            "agent": {
                "id": 114476018,
                "type": "User",
                "name": "SonOfSaturns"
            },
            "details": {
                "id": 10237523845,
                "name": "Nextbot Template",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24714214287,
            "idHash": "O3Ycj2q6atiggcW8G6QNcQ",
            "transactionType": "Purchase",
            "created": "2022-07-27T08:17:57.923Z",
            "isPending": false,
            "agent": {
                "id": 3654690339,
                "type": "User",
                "name": "graphik"
            },
            "details": {
                "id": 10038543241,
                "name": "Nextbot V1",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24704663733,
            "idHash": "ejHKEk90p67E1DvRd3AyYw",
            "transactionType": "Purchase",
            "created": "2022-07-26T20:40:02.007Z",
            "isPending": false,
            "agent": {
                "id": 90228414,
                "type": "User",
                "name": "TwinPlayz"
            },
            "details": {
                "id": 7132326235,
                "name": "AvatarCatalogBundle",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24704202020,
            "idHash": "zVoGNOS4FEaUKKtLCi7Qzw",
            "transactionType": "Purchase",
            "created": "2022-07-26T20:13:41.743Z",
            "isPending": false,
            "agent": {
                "id": 290800881,
                "type": "User",
                "name": "AB_DEVV"
            },
            "details": {
                "id": 6649525576,
                "name": "Avator editer",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24703749653,
            "idHash": "/r8uBy+2TeL3DjukprcdrA",
            "transactionType": "Purchase",
            "created": "2022-07-26T19:48:10.333Z",
            "isPending": false,
            "agent": {
                "id": 216700310,
                "type": "User",
                "name": "Vexsighted"
            },
            "details": {
                "id": 9295915935,
                "name": "(FIX) Insight's Fully Customizable Menu Guis",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24702306085,
            "idHash": "9XetHGcV1nX3lrfFFoWrFA",
            "transactionType": "Purchase",
            "created": "2022-07-26T18:28:30.33Z",
            "isPending": false,
            "agent": {
                "id": 509038592,
                "type": "User",
                "name": "purly"
            },
            "details": {
                "id": 6963394301,
                "name": "AvatarEditor [By Purly_Dev]",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24621718060,
            "idHash": "gMz7MMppoXOWcGaim4Wodg",
            "transactionType": "Purchase",
            "created": "2022-07-23T01:33:12.877Z",
            "isPending": false,
            "agent": {
                "id": 5453851,
                "type": "Group",
                "name": "Familia de John grupo de roblox :D"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 6735275521,
                    "universeId": 2548020275,
                    "name": "[ 🎃 ] Murder Mystery X FREE RADIO & HUNTER"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24593477574,
            "idHash": "CRV1PJH4dly53YNDdqqdEg",
            "transactionType": "Purchase",
            "created": "2022-07-21T19:27:19.953Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7193445686,
                "name": "Wavy Middle Part - Blonde",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24593466508,
            "idHash": "iQIY+hIsQsjzZ33jNteLpQ",
            "transactionType": "Purchase",
            "created": "2022-07-21T19:26:45.19Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7193448988,
                "name": "Straight Bangs - Blonde",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24574121349,
            "idHash": "kOagbq9pa9d2/ghOfbUx9A",
            "transactionType": "Purchase",
            "created": "2022-07-20T21:22:26.073Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 2956239660,
                "name": "Belle Of Belfast Long Red Hair",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24574112625,
            "idHash": "9neHuhUAkABd1pH5NbLaRw",
            "transactionType": "Purchase",
            "created": "2022-07-20T21:21:55.473Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 451220849,
                "name": "Lavender Updo",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24529939846,
            "idHash": "c62A5umzRLPg22rGMYT4Fw",
            "transactionType": "Purchase",
            "created": "2022-07-18T21:49:38.347Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7178737816,
                "name": "Roblox T-Shirt - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24526289793,
            "idHash": "X5RTQ+wcySpEquFm7mJOZw",
            "transactionType": "Purchase",
            "created": "2022-07-18T19:01:19.92Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9244111257,
                "name": "Wavy Middle Part - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24526186253,
            "idHash": "tsTRwtIGmnbNB6Y7YmEeEg",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:56:45.157Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 356,
                "name": "Rthro Animation Package",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24525971596,
            "idHash": "11DGtvrK5nV0HMqzsO+zLw",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:47:19.98Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 108,
                "name": "ROBLOX Girl",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24525909899,
            "idHash": "8lAIqE5o6QjBCKszxeUO3w",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:44:35.073Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7193449810,
                "name": "Straight Bangs - Brown",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24525837590,
            "idHash": "RI4cAV1LBrlJAfe5o1Maig",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:41:23.803Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 6984740059,
                "name": "Cargo Pants - Brown",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24525816593,
            "idHash": "QVW6GQk4PidePzVplZ1JoA",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:40:28.06Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7193455510,
                "name": "Braided Hair - Red",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24525799275,
            "idHash": "PojiVhXXvvG6GrLxtFC1zQ",
            "transactionType": "Purchase",
            "created": "2022-07-18T18:39:42.487Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9240752338,
                "name": "Tie-Front Top - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24476671545,
            "idHash": "948/+929k0febqsc3IhEIQ",
            "transactionType": "Purchase",
            "created": "2022-07-16T22:16:35.557Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192685245,
                "name": "Floral Swim Trunks - Blue",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 24476568942,
            "idHash": "xv7/0tX9MaK/lQFHylK5Mw",
            "transactionType": "Purchase",
            "created": "2022-07-16T22:11:18.02Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9274635732,
                "name": "Floral Swim Trunks - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 23604996321,
            "idHash": "t4H7RKKMkC7lP2RIagRGjg",
            "transactionType": "Purchase",
            "created": "2022-06-06T12:57:55.987Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9112483644,
                "name": "Striped T-Shirt - White ",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 23604759339,
            "idHash": "efC0prvXj3AUI1nW2Yhl6Q",
            "transactionType": "Purchase",
            "created": "2022-06-06T12:40:55.143Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9174391966,
                "name": "Bermuda Shorts - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 23604750185,
            "idHash": "VFbdhtyq+YfCliugMB1lrw",
            "transactionType": "Purchase",
            "created": "2022-06-06T12:40:15.92Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192681239,
                "name": "Textured Leather Pants - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 23201134629,
            "idHash": "kR2AqMGQEEt9M+gaimXJ1Q",
            "transactionType": "Purchase",
            "created": "2022-05-16T10:25:53.46Z",
            "isPending": false,
            "agent": {
                "id": 10446127,
                "type": "Group",
                "name": "Tycoon Playground"
            },
            "details": {
                "id": 10561445,
                "name": "Money1",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 6772424226,
                    "universeId": 2567557845,
                    "name": "2 Player Millionaire Tycoon"
                }
            },
            "currency": {
                "amount": -5,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 23201131825,
            "idHash": "NmbCYeiFRdlRlazp9b+8xg",
            "transactionType": "Purchase",
            "created": "2022-05-16T10:25:35.203Z",
            "isPending": false,
            "agent": {
                "id": 10446127,
                "type": "Group",
                "name": "Tycoon Playground"
            },
            "details": {
                "id": 10561450,
                "name": "Money3",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 6772424226,
                    "universeId": 2567557845,
                    "name": "2 Player Millionaire Tycoon"
                }
            },
            "currency": {
                "amount": -25,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22951966891,
            "idHash": "wDCYKqid9zcwXtMUaXMw0w",
            "transactionType": "Purchase",
            "created": "2022-05-04T18:57:58.177Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 896,
                "name": "Sneakers - White",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22951900878,
            "idHash": "jGyF2/SAO2gYl6OzoCvoCg",
            "transactionType": "Purchase",
            "created": "2022-05-04T18:53:42.747Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 18151826,
                "name": ":]",
                "type": "Asset"
            },
            "currency": {
                "amount": -15,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22951809989,
            "idHash": "P/qh8ZZY7ibWf3TQNQWi6w",
            "transactionType": "Purchase",
            "created": "2022-05-04T18:47:51.337Z",
            "isPending": false,
            "agent": {
                "id": 180242189,
                "type": "User",
                "name": "Nicki"
            },
            "details": {
                "id": 8082491357,
                "name": "White Styled Pushed Hair",
                "type": "Asset"
            },
            "currency": {
                "amount": -55,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22735054589,
            "idHash": "EDsue5zdJ6yV7VcKftOIwA",
            "transactionType": "Purchase",
            "created": "2022-04-24T09:37:09.043Z",
            "isPending": false,
            "agent": {
                "id": 8201698,
                "type": "Group",
                "name": "Snowdust's Den (Gacha Online)"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 7345769211,
                    "universeId": 2865312254,
                    "name": "Super Secret Testing Zone"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22269163270,
            "idHash": "Y3A9y1UDLlG3y7G96tZk6Q",
            "transactionType": "Purchase",
            "created": "2022-04-05T18:24:29.34Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 872,
                "name": "Roblox Sneakers - Gray",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22094391837,
            "idHash": "L6WieQy5xKodLU401Bu9+Q",
            "transactionType": "Purchase",
            "created": "2022-03-28T15:12:25.817Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192546798,
                "name": "Collared Leather Jacket - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22093382609,
            "idHash": "VbZAvR8OIqzmw+E9lI0I6w",
            "transactionType": "Purchase",
            "created": "2022-03-28T13:56:11.437Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 8516612751,
                "name": "Denim Jacket - White",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22093074682,
            "idHash": "XIFbTcxldUdIkKVPpiVf9w",
            "transactionType": "Purchase",
            "created": "2022-03-28T13:32:08.953Z",
            "isPending": false,
            "agent": {
                "id": 4096048,
                "type": "Group",
                "name": "Lobster Interactive"
            },
            "details": {
                "id": 9179820462,
                "name": "Grey Camo T-shirt",
                "type": "Asset"
            },
            "currency": {
                "amount": -50,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22079301375,
            "idHash": "UsEr4QU/LAwGE9+lfIYVmQ",
            "transactionType": "Purchase",
            "created": "2022-03-27T19:02:29.25Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192664790,
                "name": "Casual Sweats - Gray",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22079249738,
            "idHash": "LhvOTsxJDnF0M08fv8mYvA",
            "transactionType": "Purchase",
            "created": "2022-03-27T19:00:00.167Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 8516609675,
                "name": "Denim Jacket - dark Wash",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22079243267,
            "idHash": "kDyF2OJ4meg3ZpcM+5boLA",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:59:41.783Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 6984765766,
                "name": "Zip Hoodie - Orange",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22079208848,
            "idHash": "v2AaVIpPfNWA90KPy4vpBQ",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:58:02.65Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 8516620262,
                "name": "Hooded Jacket - Gray",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22079045813,
            "idHash": "cW+NvKPaBogHM2mukM3QZg",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:50:22.847Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9112492265,
                "name": "Cargo Pants - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078658534,
            "idHash": "DoiQpZtpe8QCwolPcFuYMQ",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:32:13.493Z",
            "isPending": false,
            "agent": {
                "id": 123597957,
                "type": "User",
                "name": "glowlez"
            },
            "details": {
                "id": 9180642713,
                "name": "Black Y2K Cargo Pants",
                "type": "Asset"
            },
            "currency": {
                "amount": -50,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078584897,
            "idHash": "Phifze3Jl0iOrZ137szL/w",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:28:47.71Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 741,
                "name": "Linlin",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078521931,
            "idHash": "cbBpnMaQ0XtChhkluo++sA",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:25:53.18Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 572,
                "name": "Summer",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078284824,
            "idHash": "JTGU1wAikCr6miAKxucCVA",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:15:02.687Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 573,
                "name": "Oliver",
                "type": "Bundle"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078123499,
            "idHash": "KyL+DHyhpVG+niZce7eShw",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:07:46.287Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192553841,
                "name": "Zip Hoodie - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22078079491,
            "idHash": "5yr/CHQAoEiGX9GVUWbuDQ",
            "transactionType": "Purchase",
            "created": "2022-03-27T18:05:46.6Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 9112474888,
                "name": "Basic T-Shirt - Gray",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22077770002,
            "idHash": "xZaozEbqAqkmO3exO9rgcA",
            "transactionType": "Purchase",
            "created": "2022-03-27T17:51:45.773Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 6984763785,
                "name": "Casual Sweats - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 22077627626,
            "idHash": "FTuMA3Y81W4kbXwOIxA8cA",
            "transactionType": "Purchase",
            "created": "2022-03-27T17:45:24.89Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 7192549218,
                "name": "Leather Jacket - Black",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21432950705,
            "idHash": "AbtlBRvhM12IBGE8ontDnw",
            "transactionType": "Purchase",
            "created": "2022-03-02T09:47:34.497Z",
            "isPending": false,
            "agent": {
                "id": 5069292,
                "type": "Group",
                "name": "h34rtSICK"
            },
            "details": {
                "id": 5772829552,
                "name": "[ORIG] envy y2k gyaru vamp emo goth fairy doll yay",
                "type": "Asset"
            },
            "currency": {
                "amount": -7,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21280726013,
            "idHash": "fLxhRp388fWMXsobJZ8tjw",
            "transactionType": "Purchase",
            "created": "2022-02-22T16:03:33.577Z",
            "isPending": false,
            "agent": {
                "id": 5264310,
                "type": "Group",
                "name": "Retro Dev"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 5846386835,
                    "universeId": 2082205150,
                    "name": "RetroStudio [вампир Update]"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21121549635,
            "idHash": "/kn3V7svs2WvaQv89K0qsg",
            "transactionType": "Purchase",
            "created": "2022-02-14T09:42:15.77Z",
            "isPending": false,
            "agent": {
                "id": 295182,
                "type": "Group",
                "name": "Uplift Games"
            },
            "details": {
                "id": 2215076,
                "name": "50 Bucks",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 920587237,
                    "universeId": 383310974,
                    "name": "Adopt Me!"
                }
            },
            "currency": {
                "amount": -24,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21121548439,
            "idHash": "wFxWFKqrCbaLpkPHleCkHA",
            "transactionType": "Purchase",
            "created": "2022-02-14T09:42:07.337Z",
            "isPending": false,
            "agent": {
                "id": 295182,
                "type": "Group",
                "name": "Uplift Games"
            },
            "details": {
                "id": 2215076,
                "name": "50 Bucks",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 920587237,
                    "universeId": 383310974,
                    "name": "Adopt Me!"
                }
            },
            "currency": {
                "amount": -24,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21121547168,
            "idHash": "tmVFwDzuZLPw+GnBFW83Yg",
            "transactionType": "Purchase",
            "created": "2022-02-14T09:41:58.513Z",
            "isPending": false,
            "agent": {
                "id": 295182,
                "type": "Group",
                "name": "Uplift Games"
            },
            "details": {
                "id": 2215076,
                "name": "50 Bucks",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 920587237,
                    "universeId": 383310974,
                    "name": "Adopt Me!"
                }
            },
            "currency": {
                "amount": -24,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 21121518867,
            "idHash": "jFJChkXQboTdcJB4qBa1Iw",
            "transactionType": "Purchase",
            "created": "2022-02-14T09:38:48.837Z",
            "isPending": false,
            "agent": {
                "id": 6033979,
                "type": "Group",
                "name": "Tycoon League"
            },
            "details": {
                "id": 6145940,
                "name": "50K Coins",
                "type": "DeveloperProduct",
                "place": {
                    "placeId": 6417787939,
                    "universeId": 2387716535,
                    "name": "City Life Tycoon"
                }
            },
            "currency": {
                "amount": -25,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20862244181,
            "idHash": "JPwA6wlK5Zk1MsKH7V2kXg",
            "transactionType": "Purchase",
            "created": "2022-02-01T11:25:22.32Z",
            "isPending": false,
            "agent": {
                "id": 60596019,
                "type": "User",
                "name": "Wolfpaq"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 4924922222,
                    "universeId": 1686885941,
                    "name": "Brookhaven 🏡RP"
                }
            },
            "currency": {
                "amount": -100,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20746517729,
            "idHash": "3k90o8C+JPGmANXmBnabHA",
            "transactionType": "Purchase",
            "created": "2022-01-27T13:15:36.07Z",
            "isPending": false,
            "agent": {
                "id": 1,
                "type": "User",
                "name": "Roblox"
            },
            "details": {
                "id": 311,
                "name": "Robloxian 2.0",
                "type": "Bundle"
            },
            "currency": {
                "amount": -15,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20746490470,
            "idHash": "qhc/9xoZvkZMROLiDv0OZg",
            "transactionType": "Purchase",
            "created": "2022-01-27T13:13:20.813Z",
            "isPending": false,
            "agent": {
                "id": 935289,
                "type": "Group",
                "name": "#19"
            },
            "details": {
                "id": 6672917832,
                "name": "Dark blue Boy Plaid Jacket ent",
                "type": "Asset"
            },
            "currency": {
                "amount": -5,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20746481864,
            "idHash": "kPArxAC2abuuoe7DyHRydQ",
            "transactionType": "Purchase",
            "created": "2022-01-27T13:12:39.363Z",
            "isPending": false,
            "agent": {
                "id": 5037009,
                "type": "Group",
                "name": "TPOC"
            },
            "details": {
                "id": 3642519017,
                "name": "Two Players One Console Shirt",
                "type": "Asset"
            },
            "currency": {
                "amount": -23,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20746474116,
            "idHash": "x8Vbf4+VggnW4Yh4Ufnumg",
            "transactionType": "Purchase",
            "created": "2022-01-27T13:12:01.413Z",
            "isPending": false,
            "agent": {
                "id": 2564250,
                "type": "Group",
                "name": "Nova Scotia Nighthawks™"
            },
            "details": {
                "id": 5054905199,
                "name": "Trxsh/Trash Gang Christmas slender Black emo boy5t",
                "type": "Asset"
            },
            "currency": {
                "amount": -5,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20746436104,
            "idHash": "KQLOInl+aEReUpKLMkq8oQ",
            "transactionType": "Purchase",
            "created": "2022-01-27T13:08:50.773Z",
            "isPending": false,
            "agent": {
                "id": 180242189,
                "type": "User",
                "name": "Nicki"
            },
            "details": {
                "id": 7284039539,
                "name": "White Sleepy Hair",
                "type": "Asset"
            },
            "currency": {
                "amount": -55,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20656659266,
            "idHash": "nx7HruU+eEp6TV9FdGUuGg",
            "transactionType": "Purchase",
            "created": "2022-01-22T18:36:57.593Z",
            "isPending": false,
            "agent": {
                "id": 11238153,
                "type": "User",
                "name": "Redfur_Renard"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 155010111,
                    "universeId": 73556364,
                    "name": "Animatronic World !"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20648824108,
            "idHash": "JD/dBAn+QIE6JiUxeceV7A",
            "transactionType": "Purchase",
            "created": "2022-01-22T11:22:22.2Z",
            "isPending": false,
            "agent": {
                "id": 5632608,
                "type": "Group",
                "name": "Flip's Drip"
            },
            "details": {
                "id": 6111376717,
                "name": "🖤Y2k Emo Goth Vamp🖤 Black Ripped Jeans",
                "type": "Asset"
            },
            "currency": {
                "amount": -5,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20648817579,
            "idHash": "9s9o7ZiWZTGKZ7E6uN6mvg",
            "transactionType": "Purchase",
            "created": "2022-01-22T11:21:52.443Z",
            "isPending": false,
            "agent": {
                "id": 12556581,
                "type": "Group",
                "name": "reysia"
            },
            "details": {
                "id": 7919545692,
                "name": "Emo y2k black shirt aesthetic lol boy trendy",
                "type": "Asset"
            },
            "currency": {
                "amount": -8,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20648761855,
            "idHash": "I3GEnIumOlWSy6+Efu0nIw",
            "transactionType": "Purchase",
            "created": "2022-01-22T11:17:43.84Z",
            "isPending": false,
            "agent": {
                "id": 180242189,
                "type": "User",
                "name": "Nicki"
            },
            "details": {
                "id": 7284046906,
                "name": "Red Sleepy Hair",
                "type": "Asset"
            },
            "currency": {
                "amount": -55,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20648748980,
            "idHash": "5r6sy9G9gS3rwCPk1wzU2w",
            "transactionType": "Purchase",
            "created": "2022-01-22T11:16:47.967Z",
            "isPending": false,
            "agent": {
                "id": 63700903,
                "type": "User",
                "name": "Coeptus"
            },
            "details": {
                "id": 185655149,
                "name": "Welcome to Bloxburg",
                "type": "Asset"
            },
            "currency": {
                "amount": -25,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 20300545827,
            "idHash": "JAmVvhriJJ6orHd3B+i5BQ",
            "transactionType": "Purchase",
            "created": "2022-01-06T14:57:43.793Z",
            "isPending": false,
            "agent": {
                "id": 231662,
                "type": "User",
                "name": "Zonix"
            },
            "details": {
                "id": 1565204,
                "name": "Gorillaz",
                "type": "Asset"
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 19865419910,
            "idHash": "mVgwHyuDV8cQY8QzANdlyA",
            "transactionType": "Purchase",
            "created": "2021-12-22T13:21:02.903Z",
            "isPending": false,
            "agent": {
                "id": 61648063,
                "type": "User",
                "name": "Muneeb"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 5129305072,
                    "universeId": 1782137150,
                    "name": "Friend Checker"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        },
        {
            "id": 19805449333,
            "idHash": "2BrIhKsFcLelivuGiH4paw",
            "transactionType": "Purchase",
            "created": "2021-12-19T11:53:31.137Z",
            "isPending": false,
            "agent": {
                "id": 1848960,
                "type": "User",
                "name": "Nikilis"
            },
            "details": {
                "name": "Private Server",
                "type": "PrivateServer",
                "place": {
                    "placeId": 188331334,
                    "universeId": 119460199,
                    "name": "Testing Server"
                }
            },
            "currency": {
                "amount": 0,
                "type": "Robux"
            },
            "purchaseToken": null
        }
    ]
}