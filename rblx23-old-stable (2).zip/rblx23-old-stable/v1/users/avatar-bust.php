{
  "data": [
    {
      "targetId": 1,
      "state": "Completed",
      "imageUrl": "https://tr.rbxcdn.com/c1602ad2c06d240550e238c06f935d3a/48/48/AvatarBust/Png/isCircular"
    }
  ]
}