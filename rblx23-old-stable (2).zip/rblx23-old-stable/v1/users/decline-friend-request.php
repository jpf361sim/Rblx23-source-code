<?php
include('../../site.php');

$friends = new friends;
$friends->declineFriendRequest();
?>