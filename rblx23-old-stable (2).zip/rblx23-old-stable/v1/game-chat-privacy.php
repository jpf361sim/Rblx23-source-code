{
  "gameChatPrivacy": "AllUsers"
}