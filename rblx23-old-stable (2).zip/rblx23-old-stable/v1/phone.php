{
    "countryCode": null,
    "prefix": null,
    "phone": null,
    "isVerified": false,
    "verificationCodeLength": 6,
    "canBypassPasswordForPhoneUpdate": true
}