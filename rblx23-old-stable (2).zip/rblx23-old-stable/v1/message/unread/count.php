<?php
  $data = array(
    "count" => 0
);

$json = json_encode($data);
echo $json;
