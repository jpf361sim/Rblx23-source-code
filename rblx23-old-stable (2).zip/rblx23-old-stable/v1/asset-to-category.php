<?php
$data = array(
    array(
        "additionalProp1" => 0,
        "additionalProp2" => 0,
        "additionalProp3" => 0
        )
    )
);

$json = json_encode($data);
echo $json;



