{
  "privateMessagePrivacy": "Friends"
}