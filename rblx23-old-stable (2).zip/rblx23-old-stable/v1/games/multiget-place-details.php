[
    {
        "placeId": 1,
        "name": "TEST",
        "description": "hi",
        "sourceName": "Color or Die 🎨",
        "sourceDescription": "hi",
        "url": "",
        "builder": "doggo",
        "builderId": 1,
        "hasVerifiedBadge": true,
        "isPlayable": true,
        "reasonProhibited": "None",
        "universeId": 1,
        "universeRootPlaceId": 1,
        "price": 0,
        "imageToken": "T_12931609417_7cdd"
    }
]