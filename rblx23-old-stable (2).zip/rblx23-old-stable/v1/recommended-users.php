{
  "recommendedUsers": [
    {
      "userId": 0,
      "userName": "Test",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    },
    {
      "userId": 0,
      "userName": "Test2",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    },
    {
      "userId": 0,
      "userName": "Test3",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    },
    {
      "userId": 0,
      "userName": "Test4",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    },
    {
      "userId": 0,
      "userName": "Test5",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    },
    {
      "userId": 0,
      "userName": "Test6",
      "userProfilePageUrl": "https://www.sitetest3.bladeitter.cf/users/0/profile/",
      "userPresenceType": 0
    }
  ]
}



