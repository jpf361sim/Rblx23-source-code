<?php
$data = array(
    'SuggestedGroupKeywords' => array("Experience Studios", "Building", "Roleplaying", "Fan"),
    'ShowFriendsGroupsSort' => true
);

$jsonData = json_encode($data);
echo $jsonData;
