{
  "supportedLocale": {
    "id": 1,
    "locale": "en_us",
    "name": "English(US)",
    "nativeName": "English",
    "language": {
      "id": 41,
      "name": "English",
      "nativeName": "English",
      "languageCode": "en",
      "isRightToLeft": false
    }
  },
  "nativeLanguage": {
    "id": 41,
    "name": "English",
    "nativeName": "English",
    "languageCode": "en",
    "isRightToLeft": false
  }
}